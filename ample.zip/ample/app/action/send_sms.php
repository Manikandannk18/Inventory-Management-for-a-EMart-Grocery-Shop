<?php 

if (isset($_POST)) {
    $sms_number = $_POST['sms_number'];
    $sms_message = $_POST['sms_message'];

    // $username = "sazibuddinmd9";
    // $hash = "4dd0f652609fcb876f91d3508c6533a1"; //generate token from the control panel
    // $numbers = $sms_number; //Recipient Phone Number multiple number must be separated by comma
    // $message = $sms_message;

    // $params = array('u'=>$username, 'h'=>$hash, 'op'=>'pv', 'to'=>$numbers, 'msg'=>$message);

    // $ch = curl_init();
    // curl_setopt($ch, CURLOPT_URL, "http://alphasms.biz/index.php?app=ws");
    // curl_setopt($ch, CURLOPT_POST, 1);
    // curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
    // curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    // $response = curl_exec($ch);
    // curl_close ($ch);

    // if ($response) {
    //     echo "Message send successfully";
    // }else{
    //     echo "Failed to send message ! please try again";
    // }


}

 ?>


