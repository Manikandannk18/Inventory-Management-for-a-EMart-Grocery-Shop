<?php 
	require_once '../init.php';
	$Ouser->logOut();
 ?>